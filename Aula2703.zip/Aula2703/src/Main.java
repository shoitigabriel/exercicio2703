public class Main {
    public static void main(String[] args) {
        Util util = new Util();
        util.menuPrincipal();
       //new Util().menuPrincipal();
    }
}
